<?php
defined('BASEPATH') OR exit('No direct script access allowed');

echo "\nERROR: ",
strip_tags($heading),
	"\n\n",
	strip_tags($message),
	"\n\n";