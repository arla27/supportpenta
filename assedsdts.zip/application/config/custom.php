<?php
/*
|--------------------------------------------------------------------------
| Site Languages
|--------------------------------------------------------------------------
|
| This Helps to Switch Between Languages
|
*/
$config['site_language']	= array (
    'english'=>array(
        'name'=>'english',
        'direction'=>'ltr',
        'shortcode'=>'en'
    ),
    'french'=>array(
        'name'=>'french',
        'direction'=>'ltr',
        'shortcode'=>'fr'
    )
);